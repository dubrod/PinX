--------------------
PinX
--------------------
Author: Wayne Roddy <wayne@alphatoro.com>
--------------------

A Pinterest Style Image Gallery Manager for MODx Revolution.

View the quick start on GitHub: https://github.com/alpha-toro/PinX

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/alpha-toro/PinX/issues


--------------------
Copyright Information

PinX is distributed as GPL.

