<?php
/**
 * @package pinx
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/pinxset.class.php');
class PinXSet_mysql extends PinXSet {}
?>
